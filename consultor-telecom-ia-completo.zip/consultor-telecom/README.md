# Consultor de marketing telecom IA

App de diagnóstico estratégico para empresas de telecomunicaciones, con un backend serverless que llama a Claude de forma segura.

## Por qué el despliegue anterior fallaba

- Solo se subió el archivo `.jsx` suelto, sin proyecto (`package.json`, `index.html`, etc.), así que Netlify no tenía nada que construir.
- La llamada a la API de Anthropic se hacía directo desde el navegador, lo cual no funciona fuera del entorno de artifacts de Claude.ai (no hay clave, y no es seguro exponerla en el cliente de todas formas).

Este proyecto soluciona ambas cosas: es un proyecto Vite completo, y la llamada a Claude pasa por una función serverless (`netlify/functions/consultar.js`) que guarda la clave de API en el servidor, nunca en el navegador.

## Cómo desplegar

1. Sube TODO este contenido (no solo el .jsx) a tu repo de GitHub, reemplazando lo que había.
2. En Netlify, en el proyecto, ve a **Configuración del sitio → Environment variables** y añade:
   - `ANTHROPIC_API_KEY` = tu clave de la consola de Anthropic (console.anthropic.com → API Keys)
3. Vuelve a desplegar (Netlify detecta el `netlify.toml` y hace `npm run build` automáticamente).
4. Netlify también detecta la carpeta `netlify/functions` y despliega `consultar.js` como función sin configuración extra.

## Desarrollo local

```
npm install
npm run dev
```

Para probar la función localmente necesitas la CLI de Netlify (`npm install -g netlify-cli` y luego `netlify dev`), porque `npm run dev` solo (Vite) no ejecuta funciones serverless.

## Nota sobre costos

Cada informe generado consume tokens de la API de Anthropic (pagados con tu clave). Antes de ofrecer esto como servicio con volumen, revisa los precios actuales en la consola de Anthropic y considera un límite de uso o un pequeño costo por informe.
