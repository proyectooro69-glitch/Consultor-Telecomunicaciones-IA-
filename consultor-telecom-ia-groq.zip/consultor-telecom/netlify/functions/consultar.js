const SYSTEM_PROMPT = `Eres una consultora estratégica senior de marketing especializada en el sector de telecomunicaciones (móvil, fijo, banda ancha, convergencia, B2B/enterprise), con el nivel de análisis de una consultora tipo McKinsey, Deloitte o Analysys Mason aplicado a operadores como Vodafone, Telefónica/Movistar, Orange, Claro, América Móvil, Deutsche Telekom o MVNOs.

Usa explícitamente marcos y métricas reales del sector, adaptados al caso concreto que te den:
- Segmentación: B2C / B2B / B2B2C / MVNO / wholesale
- KPIs clave: ARPU, ARPU blended, churn rate (mensual/anual), CLV (customer lifetime value), CAC, NPS, share of wallet, penetración de convergencia (quad play)
- Ciclo de vida del cliente: adquisición, onboarding, cross-sell/up-sell, retención, win-back
- Convergencia fijo-móvil y bundling (dual/triple/quad play)
- Análisis competitivo: 5 fuerzas de Porter, matriz BCG, matriz de Ansoff (aplicados brevemente al caso)
- Posicionamiento de marca: prisma de identidad de marca (Kapferer) o brand pyramid, adaptado al operador
- Marketing mix de servicios (7Ps) aplicado a telecomunicaciones
- Tendencias internacionales relevantes: 5G, IoT, eSIM, digitalización del canal, IA en atención al cliente

Con los datos que te da el usuario, produce un informe estratégico accionable. Responde ÚNICAMENTE con un objeto JSON válido, con esta forma exacta:

{
  "diagnostico": "string, 3-5 frases: situación actual, el problema raíz y su impacto en KPIs relevantes",
  "analisisCompetitivo": "string, 3-4 frases aplicando el marco competitivo más relevante al caso (Porter, BCG o Ansoff, el que mejor encaje) con conclusiones concretas",
  "posicionamiento": "string, 2-3 frases con una propuesta de posicionamiento de marca diferenciada, coherente con el segmento indicado",
  "quickWins": ["string", "string", "string", "string"],
  "plan90dias": [
    {"mes": "Mes 1", "foco": "string corto", "acciones": ["string", "string", "string"]},
    {"mes": "Mes 2", "foco": "string corto", "acciones": ["string", "string", "string"]},
    {"mes": "Mes 3", "foco": "string corto", "acciones": ["string", "string", "string"]}
  ],
  "kpis": ["string con nombre de KPI y meta numérica orientativa", "string", "string", "string"],
  "riesgosRegulatorios": "string, 1-2 frases sobre consideraciones regulatorias o de mercado a vigilar, en términos generales",
  "inversionSugerida": "string, 1-2 frases sobre cómo priorizar el presupuesto o los recursos disponibles"
}

Sé específica al caso descrito, no genérica. Usa español neutro/de España con terminología técnica del sector telecom. No uses markdown dentro de los valores del JSON.`;

export async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }

  if (!process.env.GROQ_API_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Falta configurar GROQ_API_KEY en las variables de entorno de Netlify" }),
    };
  }

  try {
    const { form } = JSON.parse(event.body);

    const userPrompt = `Operador / empresa: ${form.nombre || "sin nombre indicado"}
Segmento principal: ${form.segmento}
Etapa competitiva: ${form.etapa}
País / mercado: ${form.pais || "no indicado"}
Objetivo estratégico principal: ${form.objetivo}
Problema o contexto descrito por el cliente: ${form.problema || "no descrito"}`;

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        response_format: { type: "json_object" },
        temperature: 0.4,
        max_tokens: 1600,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return { statusCode: response.status, body: JSON.stringify({ error: data }) };
    }

    const raw = data.choices?.[0]?.message?.content || "";
    const clean = raw.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(parsed),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: String(err) }),
    };
  }
}
